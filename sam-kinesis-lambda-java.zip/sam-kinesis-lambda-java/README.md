# sam-kinesis-lambda-java

SAM based Kinesis Java Lambda Consumer application